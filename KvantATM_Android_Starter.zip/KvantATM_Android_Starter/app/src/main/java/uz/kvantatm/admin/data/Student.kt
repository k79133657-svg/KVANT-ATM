package uz.kvantatm.admin.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "students")
data class Student(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fullName: String,
    val phone: String = "",
    val groupName: String = "",
    val monthlyFee: Long = 0,
    val isActive: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis(),
    val syncPending: Boolean = true
)
